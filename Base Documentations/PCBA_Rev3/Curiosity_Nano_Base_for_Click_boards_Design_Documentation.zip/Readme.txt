Filelist:
Curiosity_Nano_Base_for_Click_boards_layer_plots_release_rev3.pdf : PCB Layer Plots
Curiosity_Nano_Base_for_Click_boards_design_documentation_release_rev3.pdf : Design Documentation with Bom
BOM\Bill of Materials Print-Curiosity_Nano_Base_for_Click_boards_release_rev3.xls : BOM, fitted components
ExportSTEP\Curiosity_Nano_Base_for_Click_boards_release_rev3.step : 3D Model of PCBA
NC Drill\Curiosity_Nano_Base_for_Click_boards_release_rev3.drl : Drill files, gerber
NC Drill\Curiosity_Nano_Base_for_Click_boards_release_rev3.drr : Drill Files Report
ODB\Curiosity_Nano_Base_for_Click_boards_release_rev3.zip : ODB++ Files
Pick Place\Pick Place for Curiosity_Nano_Base_for_Click_boards_release_rev3.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for Curiosity_Nano_Base_for_Click_boards_release_rev3.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for Curiosity_Nano_Base_for_Click_boards_release_rev3.csv : Assembly Testpoint report, csv
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GTP : Gerber files for Top Paste
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GTS : Gerber files for Top Solder
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GTO : Gerber files for Top Overlay
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GBS : Gerber files for Bottom Solder
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GBO : Gerber files for Bottom Overlay
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GM1 : Gerber files for Board (M1)
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GP2 : Gerber files for Internal Plane 2 Pwr
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GP1 : Gerber files for Internal Plane 1 Gnd
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GTL : Gerber files for Top Layer
Gerber\Curiosity_Nano_Base_for_Click_boards_release_rev3.GBL : Gerber files for Bottom Layer
NC Drill\Curiosity_Nano_Base_for_Click_boards_release_rev3.txt : Drill files, ASCII
NC Drill\Curiosity_Nano_Base_for_Click_boards_release_rev3.LDP : Layer Pairs Definition
